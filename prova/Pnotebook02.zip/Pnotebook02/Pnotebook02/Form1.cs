﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            double[] matriz = new double[6];
            string stringona;
            double mediaModelo=0;
            double mediaGeral = 0;
            double valor;
            int i;

                for (i = 0; i < 6; i++)
                {
                    stringona = Interaction.InputBox("insira os valores de cada modelo", 
                        "entrada de dados");
                    if (!double.TryParse(stringona, out valor) || valor < 0) 
                    {
                        MessageBox.Show("valor inválido");
                        i--;
                    }
                    else
                        matriz[i] = valor;
                    lbNotebooks.Items.Add($"o valor é: {stringona}");
                    mediaModelo = (mediaModelo+valor);
                    mediaGeral = (mediaGeral+valor);
                }
                lbNotebooks.Items.Add($"a media é: {mediaModelo/3}");
                lbNotebooks.Items.Add($"a media geral é: {mediaGeral/6}");
          
            






        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbNotebooks.Items.Clear();
        }
    }
}
