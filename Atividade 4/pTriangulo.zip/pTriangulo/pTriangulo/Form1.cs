﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTriangulo
{
    public partial class Form1 : Form
    {
        double a;
        double b;
        double c;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out a))
            {
                errA.SetError(txtNum1, "dados inválidos");
                txtNum1.Focus();

            }
            else
                errA.SetError(txtNum1, "");


        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out b))
            {
                errB.SetError(txtNum2, "dados inválidos");
                txtNum2.Focus();

            }
            else
                errB.SetError(txtNum2, "");
        }

        private void txtNum3_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum3.Text, out c))
            {
                errA.SetError(txtNum3, "dados inválidos");
                txtNum3.Focus();

            }
            else
                errC.SetError(txtNum3, "");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(b - c)) < a && a < b + c && (Math.Abs(a - c)) < b && b < a + c && (Math.Abs(a - b)) < c && c < a + b)
            {
                if (a == b && b == c)
                    MessageBox.Show("Trinagulo equilátero");
                else if (a == b || a == c || b == c)
                    MessageBox.Show("Triangulo isóceles");
                else
                    MessageBox.Show("Triangulo escaleno");

            }
            else
                MessageBox.Show("Não é um triângulo");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtNum3.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
            "Você quer sair?",
            "Confirmação",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
                Close();
        }
    }
}
